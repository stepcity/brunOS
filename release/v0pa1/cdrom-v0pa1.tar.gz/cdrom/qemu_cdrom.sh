#!/bin/bash
qemu-system-i386 -cdrom ./os.iso
